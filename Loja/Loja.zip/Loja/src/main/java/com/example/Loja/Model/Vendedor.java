package com.example.Loja.Model;

import com.example.Loja.Model.Cliente;
import com.example.Loja.Model.Loja;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Vendedor {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;
    private String cpf;
    private String nome;
    private String cargo;

    @OneToMany(mappedBy = "vendedor")
    private List<Cliente> clientes;

    @ManyToMany
    @JoinTable(name = "loja_vendedor",
            joinColumns = @JoinColumn(name = "vendedor_id"),
            inverseJoinColumns = @JoinColumn(name = "loja_id"))
    private List<Loja> Lojas = new ArrayList<>();


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public Cliente getCliente() {
        return (Cliente) clientes;
    }

    public void setCliente(Cliente clientes) {
        this.clientes = (List<Cliente>) clientes;
    }

    public Loja getLoja() {
        return (Loja) Lojas;
    }

    public void setLoja(Loja lojas) {
        this.Lojas = (List<Loja>) lojas;
    }
}

